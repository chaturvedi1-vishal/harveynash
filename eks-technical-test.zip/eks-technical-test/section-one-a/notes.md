# Section 1(a) – Amazon EKS cluster

The solution provides:

- A new VPC
- An EKS cluster capable of running at least 250 pods
- 28 GB allocatable memory per node
- Resilience to one AZ failure
- Full monitoring and logging via AWS services
